/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.poe_1;



import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Pattern;

public class POE_1 {

    private static final Scanner scanner = new Scanner(System.in);
    private static final ArrayList<User> users = new ArrayList<>();
    private static String loginStatusMessage = "";

    public static void main(String[] args) {
        System.out.println(registerUser());

        boolean loggedIn = loginUser();
        System.out.println(returnLoginStatus(loggedIn));
    }

    // User class to store user details
    static class User {
        String firstName;
        String lastName;
        String phoneNumber;
        String username;
        String password;

        User(String firstName, String lastName, String phoneNumber, String username, String password) {
            this.firstName = firstName;
            this.lastName = lastName;
            this.phoneNumber = phoneNumber;
            this.username = username;
            this.password = password;
        }
    }

    // Validate username: must contain underscore and be <= 5 chars
    public static boolean checkUserName(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    // Validate password with regex
    public static boolean checkPasswordComplexity(String password) {
        String pattern = "^(?=.*[A-Z])(?=.*\\d)(?=.*[!@#$%^&*()_+=\\-{}\\[\\]:;\"'<>,.?/~`|]).{8,}$";
        return Pattern.matches(pattern, password);
    }

    // Validate SA phone number format: +27 followed by 9 digits
    public static boolean checkCellPhoneNumber(String phoneNumber) {
        String pattern = "^\\+27\\d{9}$";
        return Pattern.matches(pattern, phoneNumber);
    }

    // Register a new user
    public static String registerUser() {
        System.out.println("--- User Registration ---");

        System.out.print("Enter First Name: ");
        String firstName = scanner.nextLine();

        System.out.print("Enter Last Name: ");
        String lastName = scanner.nextLine();

        String username;
        do {
            System.out.print("Enter Username (must contain '_' and max 5 characters): ");
            username = scanner.nextLine();

            if (!checkUserName(username)) {
                System.out.println("Invalid username. Please try again.");
            } else {
                System.out.println("Username successfully captured.");
                break;
            }
        } while (true);

        String password;
        do {
            System.out.print("Enter Password: ");
            password = scanner.nextLine();

            if (!checkPasswordComplexity(password)) {
                System.out.println("Password must contain at least 8 characters, an uppercase letter, a number, and a special character.");
            } else {
                System.out.println("Password successfully captured.");
                break;
            }
        } while (true);

        String phoneNumber;
        do {
            System.out.print("Enter Cell Phone (+27xxxxxxxxx): ");
            phoneNumber = scanner.nextLine();

            if (!checkCellPhoneNumber(phoneNumber)) {
                System.out.println("Invalid phone number. Please try again.");
            } else {
                System.out.println("Phone number successfully captured.");
                break;
            }
        } while (true);

        users.add(new User(firstName, lastName, phoneNumber, username, password));
        return "Registration complete!";
    }

    // Login existing user
    public static boolean loginUser() {
        System.out.println("--- User Login ---");

        System.out.print("Enter Username: ");
        String usernameInput = scanner.nextLine();

        for (User user : users) {
            if (user.username.equals(usernameInput)) {
                while (true) {
                    System.out.print("Enter Password: ");
                    String passwordInput = scanner.nextLine();

                    if (user.password.equals(passwordInput)) {
                        loginStatusMessage = "Welcome " + user.firstName + " " + user.lastName + ", it’s great to see you again.";
                        return true;
                    } else {
                        System.out.println("Password incorrect. Please try again.");
                    }
                }
            }
        }

        loginStatusMessage = "Username not found. Please register first.";
        return false;
    }

    // Return login status message
    public static String returnLoginStatus(boolean status) {
        return loginStatusMessage;
    }
}
